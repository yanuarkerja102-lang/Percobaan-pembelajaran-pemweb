<?php
// includes/footer.php
?>
</main> <!-- akhir main/content -->

<!-- Bootstrap JS bundle (termasuk Popper) - diperlukan untuk dropdown, toggler, tooltip -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<!-- Script tambahan (opsional) -->
<script>
  // contoh: aktifkan semua tooltip jika perlu
  // const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
  // tooltipTriggerList.map(function (el) { return new bootstrap.Tooltip(el) })
</script>
</body>
</html>
