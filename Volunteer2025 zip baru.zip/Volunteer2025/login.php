<?php
// login.php (gabungan user + admin hidden)
session_start();
require_once __DIR__ . '/header.php';
require_once __DIR__ . '/db_config.php';

$ADMIN_LOGIN_CODE = '01234567890'; // ubah sesuai keinginan
$flash = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $want_admin = ($_POST['want_admin'] ?? '0') === '1';
    $admin_code_submitted = $_POST['admin_code'] ?? '';

    if ($email === '' || $password === '') {
        $flash = 'Email dan password wajib diisi.';
    } else {
        try {
            $stmt = $pdo->prepare("SELECT * FROM users WHERE email = :email LIMIT 1");
            $stmt->execute([':email' => $email]);
            $user = $stmt->fetch();

            if (!$user) {
                $flash = 'Email atau password salah.';
            } else {
                // cek password (bisa hash atau plain)
                $passwordOk = password_verify($password, $user['password']) || $password === $user['password'];

                if ($passwordOk) {
                    $role = strtolower($user['role'] ?? '');

                    // Jika mode admin diaktifkan
                    if ($want_admin) {
                        if ($admin_code_submitted !== $ADMIN_LOGIN_CODE) {
                            $flash = 'Kode rahasia admin salah.';
                        } elseif ($role !== 'admin') {
                            $flash = 'Akun ini bukan admin.';
                        } else {
                            session_regenerate_id(true);
                            $_SESSION['user_id'] = $user['id'];
                            $_SESSION['user_email'] = $user['email'];
                            $_SESSION['role'] = $role;
                            header('Location: admin_dashboard.php');
                            exit;
                        }
                    } else {
                        if ($role === 'admin') {
                            $flash = 'Gunakan mode admin untuk login akun admin.';
                        } else {
                            session_regenerate_id(true);
                            $_SESSION['user_id'] = $user['id'];
                            $_SESSION['user_email'] = $user['email'];
                            $_SESSION['role'] = $role;
                            header('Location: profile.php');
                            exit;
                        }
                    }
                } else {
                    $flash = 'Email atau password salah.';
                }
            }
        } catch (Exception $e) {
            error_log('[login.php] ' . $e->getMessage());
            $flash = 'Terjadi kesalahan sistem.';
        }
    }
}
?>
<section>
  <h2>Login</h2>
  <?php if ($flash): ?>
    <p><strong><?php echo htmlspecialchars($flash); ?></strong></p>
  <?php endif; ?>
  <form method="post" action="">
    <label>Email:</label>
    <input type="email" name="email" required>

    <label>Password:</label>
    <input type="password" name="password" required>

    <input type="hidden" id="want_admin" name="want_admin" value="0">

    <div id="admin-panel" style="display:none; margin-top:12px; padding:10px; border:1px dashed #bbb; border-radius:6px; background:#fafafa;">
      <p><strong>Mode Admin (tersembunyi)</strong></p>
      <label>Kode Rahasia Admin</label>
      <input type="password" id="admin_code" name="admin_code" autocomplete="off">
    </div>

    <div style="margin-top:10px;">
      <button type="submit">Login</button>
      <span style="margin-left:12px;">Belum punya akun? <a href="register.php">Daftar</a></span>
    </div>
  </form>

  <hr>
  <p>Klik area di bawah 5 kali atau tekan Ctrl+Alt+A untuk membuka mode admin.</p>
  <div id="secret-area" style="width:100%;height:20px;"></div>
</section>

<script>
(function(){
  const secretArea = document.getElementById('secret-area');
  const adminPanel = document.getElementById('admin-panel');
  const wantAdmin = document.getElementById('want_admin');
  let clicks = 0, timer = null;

  secretArea.addEventListener('click', function() {
    clicks++;
    clearTimeout(timer);
    timer = setTimeout(()=>{ clicks = 0; }, 2000);
    if (clicks >= 5) { togglePanel(); clicks = 0; }
  });

  document.addEventListener('keydown', function(e){
    if (e.ctrlKey && e.altKey && (e.key === 'a' || e.key === 'A')) togglePanel();
  });

  function togglePanel(){
    const visible = adminPanel.style.display === 'block';
    adminPanel.style.display = visible ? 'none' : 'block';
    wantAdmin.value = visible ? '0' : '1';
  }
})();
</script>

<?php require_once __DIR__ . '/footer.php'; ?>
