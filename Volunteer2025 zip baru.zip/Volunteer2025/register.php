<?php
// register.php
session_start();
require_once __DIR__ . '/header.php';
require_once __DIR__ . '/db_config.php';

// --- Konfigurasi ---
$ADMIN_REGISTRATION_CODE = '01234567890'; // ubah sesuai keinginan
// --------------------

// pesan untuk user
$message = '';
$errors = [];

// helper cek email unik
function email_exists($pdo, $email) {
    $stmt = $pdo->prepare("SELECT id FROM users WHERE email = :email LIMIT 1");
    $stmt->execute([':email' => $email]);
    return (bool)$stmt->fetch();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // ambil data dari form
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    // mode admin tersembunyi
    $wants_admin = isset($_POST['want_admin']) && $_POST['want_admin'] === '1';
    $admin_code_submitted = $_POST['admin_code'] ?? '';

    // validasi dasar
    if ($name === '') $errors[] = 'Nama lengkap wajib diisi.';
    if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Email tidak valid.';
    if ($password === '') $errors[] = 'Password wajib diisi.';
    if ($password !== $confirm) $errors[] = 'Konfirmasi password tidak cocok.';
    if (email_exists($pdo, $email)) $errors[] = 'Email sudah terdaftar.';

    // validasi admin code jika ingin daftar admin
    $can_create_admin = false;
    if ($wants_admin) {
        if ($admin_code_submitted === '') {
            $errors[] = 'Kode rahasia admin wajib diisi untuk membuat akun admin.';
        } elseif (!hash_equals($ADMIN_REGISTRATION_CODE, $admin_code_submitted)) {
            $errors[] = 'Kode rahasia admin salah.';
        } else {
            $can_create_admin = true;
        }
    }

    if (empty($errors)) {
        // role: admin jika disetujui, volunteer untuk umum
        $role = $can_create_admin ? 'admin' : 'volunteer';

        // hash password aman
        $hash = password_hash($password, PASSWORD_DEFAULT);

        try {
            $stmt = $pdo->prepare("
                INSERT INTO users (name, email, password, role)
                VALUES (:name, :email, :password, :role)
            ");
            $stmt->execute([
                ':name' => $name,
                ':email' => $email,
                ':password' => $hash,
                ':role' => $role
            ]);

            if ($role === 'admin') {
                $message = "✅ Akun <strong>admin</strong> berhasil dibuat!";
            } else {
                $message = "✅ Pendaftaran berhasil. Silakan <a href='login.php'>login</a>.";
            }

        } catch (Exception $e) {
            $errors[] = 'Gagal menyimpan ke database: ' . $e->getMessage();
        }
    }
}
?>

<style>
.register-box { max-width:720px; margin:20px auto; padding:18px; border:1px solid #ddd; border-radius:8px; background:#fff; }
.input-row { margin-bottom:12px; }
label { display:block; font-weight:600; margin-bottom:6px; }
input[type="text"], input[type="email"], input[type="password"] {
  width:100%; padding:8px; border:1px solid #ccc; border-radius:4px;
}
button.primary { padding:10px 16px; border-radius:6px; border:0; background:#007bff; color:#fff; cursor:pointer; }
.small { font-size:0.9rem; color:#666; }
#admin-panel { display:none; margin-top:12px; padding:12px; border:1px dashed #bbb; border-radius:6px; background:#fafafa; }
</style>

<div class="register-box">
  <h2>Registrasi Relawan</h2>

  <?php if ($message): ?>
    <p style="color:green;"><strong><?php echo $message; ?></strong></p>
  <?php endif; ?>

  <?php if (!empty($errors)): ?>
    <div style="color:#b00020;">
      <ul>
        <?php foreach ($errors as $err): ?>
          <li><?php echo htmlspecialchars($err); ?></li>
        <?php endforeach; ?>
      </ul>
    </div>
  <?php endif; ?>

  <form method="post" action="">
    <div class="input-row">
      <label>Nama Lengkap</label>
      <input type="text" name="name" value="<?php echo htmlspecialchars($_POST['name'] ?? ''); ?>" required>
    </div>

    <div class="input-row">
      <label>Email</label>
      <input type="email" name="email" value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>" required>
    </div>

    <div class="input-row">
      <label>Password</label>
      <input type="password" name="password" required>
    </div>

    <div class="input-row">
      <label>Konfirmasi Password</label>
      <input type="password" name="confirm_password" required>
    </div>

    <!-- hidden flag -->
    <input type="hidden" id="want_admin" name="want_admin" value="0">

    <!-- panel admin -->
    <div id="admin-panel">
      <p class="small">Panel tersembunyi: masukkan kode rahasia untuk membuat akun <strong>admin</strong>.</p>
      <div class="input-row">
        <label>Kode Rahasia Admin</label>
        <input type="password" id="admin_code" name="admin_code" autocomplete="off">
      </div>
    </div>

    <div style="margin-top:10px;">
      <button class="primary" type="submit">Daftar</button>
      <span class="small" style="margin-left:12px;">Sudah punya akun? <a href="login.php">Login</a></span>
    </div>
  </form>

  <hr>
  <p class="small">Klik area di bawah 5 kali atau tekan Ctrl+Alt+A untuk membuka panel admin tersembunyi.</p>
  <div id="secret-area" title="Klik 5x untuk membuka panel admin" style="width:100%; height:24px;"></div>
</div>

<script>
// klik 5x untuk menampilkan panel admin tersembunyi
(function(){
  const secretArea = document.getElementById('secret-area');
  const adminPanel = document.getElementById('admin-panel');
  const wantAdmin = document.getElementById('want_admin');
  let clicks = 0;
  let timer = null;

  secretArea.addEventListener('click', function() {
    clicks++;
    if (timer) clearTimeout(timer);
    timer = setTimeout(()=>{ clicks = 0; }, 2000);
    if (clicks >= 5) togglePanel();
  });

  document.addEventListener('keydown', function(e){
    if (e.ctrlKey && e.altKey && (e.key === 'a' || e.key === 'A')) togglePanel();
  });

  function togglePanel(){
    const visible = adminPanel.style.display === 'block';
    adminPanel.style.display = visible ? 'none' : 'block';
    wantAdmin.value = visible ? '0' : '1';
    if (!visible) document.getElementById('admin_code').focus();
  }
})();
</script>

<?php require_once __DIR__ . '/footer.php'; ?>
