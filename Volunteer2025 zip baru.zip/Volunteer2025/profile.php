<?php
session_start();
require_once __DIR__ . '/db_config.php';

// Cek login
if (!isset($_SESSION['user_id'])) {
    header('Location: /volunteer2025/login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// === Upload foto profil (langsung di halaman ini) ===
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['foto_profil'])) {
    $foto = $_FILES['foto_profil'];

    if ($foto['error'] === UPLOAD_ERR_OK) {
        $ext = strtolower(pathinfo($foto['name'], PATHINFO_EXTENSION));
        $allowed = ['jpg', 'jpeg', 'png', 'gif'];

        if (in_array($ext, $allowed)) {
            $nama_file = time() . "_user_" . $user_id . "." . $ext;
            $target_dir = __DIR__ . "/uploads/";
            $target_file = $target_dir . $nama_file;

            if (!is_dir($target_dir)) {
                mkdir($target_dir, 0777, true);
            }

            if (move_uploaded_file($foto['tmp_name'], $target_file)) {
                $sql = "UPDATE users SET foto_profil = :foto WHERE id = :id";
                $stmt = $pdo->prepare($sql);
                $stmt->execute(['foto' => $nama_file, 'id' => $user_id]);
                $success_msg = "Foto profil berhasil diperbarui!";
            } else {
                $error_msg = "Gagal mengunggah foto.";
            }
        } else {
            $error_msg = "Format file tidak didukung (hanya jpg, jpeg, png, gif).";
        }
    }
}

// === Ambil data user ===
$stmt = $pdo->prepare("SELECT id, nama, email, jenis_kelamin, no_hp, role, foto_profil FROM users WHERE id = :id");
$stmt->execute(['id' => $user_id]);
$user = $stmt->fetch();

if (!$user) {
    exit("User tidak ditemukan.");
}

// === Ambil laporan kegiatan (jika tabel tersedia) ===
try {
    $laporan_stmt = $pdo->prepare("SELECT judul, deskripsi, tanggal FROM laporan_kegiatan WHERE user_id = :id ORDER BY tanggal DESC");
    $laporan_stmt->execute(['id' => $user_id]);
    $laporan = $laporan_stmt->fetchAll();
} catch (PDOException $e) {
    $laporan = [];
}

// Sertakan header
include __DIR__ . '/header.php';
?>

<div class="container">
  <div class="profile-card">
    <div class="profile-top">
      <div class="profile-photo">
        <img src="/volunteer2025/uploads/<?= htmlspecialchars($user['foto_profil'] ?? 'default.png') ?>"
             alt="Foto Profil" class="rounded">
        <form method="POST" enctype="multipart/form-data" class="upload-form">
          <input type="file" name="foto_profil" accept=".jpg,.jpeg,.png,.gif" required>
          <button type="submit" class="btn-primary">Ganti Foto</button>
        </form>

        <?php if (isset($success_msg)): ?>
          <p class="success"><?= htmlspecialchars($success_msg) ?></p>
        <?php elseif (isset($error_msg)): ?>
          <p class="error"><?= htmlspecialchars($error_msg) ?></p>
        <?php endif; ?>
      </div>

      <div class="profile-info">
        <h2><?= htmlspecialchars($user['nama']) ?></h2>
        <p><strong>Email:</strong> <?= htmlspecialchars($user['email']) ?></p>
        <p><strong>No HP:</strong> <?= htmlspecialchars($user['no_hp']) ?></p>
        <p><strong>Jenis Kelamin:</strong> <?= htmlspecialchars($user['jenis_kelamin']) ?></p>
        <p><strong>Role:</strong> <?= htmlspecialchars($user['role']) ?></p>
        <a href="/volunteer2025/logout.php" class="btn-logout">Logout</a>
      </div>
    </div>

    <hr>

    <div class="laporan-section">
      <h3>📋 Laporan Kegiatan</h3>
      <?php if (!empty($laporan)): ?>
        <table class="laporan-table">
          <thead>
            <tr>
              <th>Judul</th>
              <th>Deskripsi</th>
              <th>Tanggal</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($laporan as $item): ?>
              <tr>
                <td><?= htmlspecialchars($item['judul']) ?></td>
                <td><?= htmlspecialchars($item['deskripsi']) ?></td>
                <td><?= htmlspecialchars($item['tanggal']) ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      <?php else: ?>
        <p class="text-muted">Belum ada laporan kegiatan.</p>
      <?php endif; ?>
    </div>
  </div>
</div>

</main>
</body>
</html>

