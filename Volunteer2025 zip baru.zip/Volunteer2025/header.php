<?php
// includes/header.php
// PENTING: session_start harus dipanggil sebelum output HTML
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// koneksi DB (pastikan db_config.php mendefinisikan $pdo)
require_once $_SERVER['DOCUMENT_ROOT'] . '/Volunteer2025/db_config.php';

// ambil data user jika login
$user = null;
if (!empty($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $stmt = $pdo->prepare("SELECT foto_profil, nama FROM users WHERE id = ? LIMIT 1");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
}

// path fallback foto
$foto_profil = '/VOLUNTEER2025/img/default-profile.png';
if (!empty($user['foto_profil'])) {
    $foto_profil = '/VOLUNTEER2025/uploads/' . htmlspecialchars($user['foto_profil']);
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Portal Relawan BAZNAS Jatim</title>

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

  <!-- CSS aplikasi -->
  <link rel="stylesheet" href="/VOLUNTEER2025/assets/css/style.css">

  <style>
    /* Custom Navbar BAZNAS */
    .navbar-baznas { background-color: #1e7d36; }
    .navbar-baznas .navbar-brand, .navbar-baznas .nav-link { color: #fff !important; }
    .navbar-baznas .nav-link:hover { color: #ffd366 !important; }
    .logo-baznas { height: 56px; width: auto; object-fit: contain; }
    .nav-profile { width:34px; height:34px; object-fit:cover; border-radius:50%; }
    .btn-logout { border-radius:8px; }
    /* small spacing on nav items */
    .nav-item + .nav-item { margin-left: 6px; }
  </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-baznas navbar-dark shadow-sm">
  <div class="container-fluid">
    <!-- Logo + Brand -->
    <a class="navbar-brand d-flex align-items-center" href="/VOLUNTEER2025/beranda.php">
      <img src="/VOLUNTEER2025/assets/img/logo-baznas.png" alt="Logo BAZNAS" class="logo-baznas me-2">
      <span class="fw-bold">Portal Relawan & Volunteer BAZNAS Jatim</span>
    </a>

    <!-- Toggler (untuk mobile) -->
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNavbar"
            aria-controls="mainNavbar" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <!-- Links -->
    <div class="collapse navbar-collapse" id="mainNavbar">
      <ul class="navbar-nav ms-auto align-items-lg-center">
        <li class="nav-item"><a class="nav-link" href="/VOLUNTEER2025/beranda.php">Beranda</a></li>
        <li class="nav-item"><a class="nav-link" href="/VOLUNTEER2025/program.php">Program</a></li>
        <li class="nav-item"><a class="nav-link" href="/VOLUNTEER2025/forum.php">Forum</a></li>

        <?php if (!empty($_SESSION['user_id'])): ?>
          <!-- Profil di dropdown, avatar + menu -->
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" id="profilDropdown"
               role="button" data-bs-toggle="dropdown" aria-expanded="false">
              <img src="<?= $foto_profil ?>" alt="Avatar" class="nav-profile me-2">
              <?= !empty($user['nama']) ? htmlspecialchars($user['nama']) : 'Profil' ?>
            </a>
            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="profilDropdown">
              <li><a class="dropdown-item" href="/VOLUNTEER2025/profile.php">Lihat Profil</a></li>
            </ul>
          </li>

          <!-- Tombol Logout terpisah (sesuai permintaan) -->
          <li class="nav-item ms-3">
            <a class="btn btn-outline-light btn-sm btn-logout" href="/VOLUNTEER2025/logout.php">Logout</a>
          </li>

        <?php else: ?>
          <!-- Tidak login: tampilkan Login & Daftar -->
          <li class="nav-item ms-3">
            <a class="btn btn-outline-light btn-sm" href="/VOLUNTEER2025/login.php">Login</a>
          </li>
          <li class="nav-item ms-2">
            <a class="btn btn-light btn-sm" href="/VOLUNTEER2025/register.php">Daftar</a>
          </li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>

<main class="container mt-4">
