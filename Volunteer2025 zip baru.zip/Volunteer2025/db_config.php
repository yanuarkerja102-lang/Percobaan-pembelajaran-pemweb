<?php
// db_config.php
declare(strict_types=1);

/**
 * Konfigurasi PDO untuk koneksi database.
 * - Mendukung environment variables: DB_HOST, DB_PORT, DB_NAME, DB_USER, DB_PASS, DB_CHARSET, DB_PERSISTENT
 * - Jika env var tidak tersedia, menggunakan nilai default (sesuaikan jika perlu)
 * - Menyimpan $pdo sebagai PDO instance global untuk digunakan aplikasi
 *
 * Catatan keamanan:
 * - Sebaiknya atur DB credentials sebagai environment variables (mis. di Apache/Nginx/FPM config atau .env yang tidak di-commit).
 * - Jangan menampilkan pesan error database ke pengguna.
 */

// jika sudah ada koneksi PDO, tidak membuat lagi
if (isset($pdo) && $pdo instanceof PDO) {
    return;
}

// baca konfigurasi dari environment (fallback ke nilai default yang Anda pakai sebelumnya)
$host    = getenv('DB_HOST')    ?: '127.0.0.1';
$port    = getenv('DB_PORT')    ?: '3306';
$db      = getenv('DB_NAME')    ?: 'volunteer_db';
$user    = getenv('DB_USER')    ?: 'root';
$pass    = getenv('DB_PASS')    ?: '';
$charset = getenv('DB_CHARSET') ?: 'utf8mb4';

// Data Source Name (DSN)
$dsn = "mysql:host={$host};port={$port};dbname={$db};charset={$charset}";

// PDO options
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

// optional: persistent connection jika environment menentukannya
if (getenv('DB_PERSISTENT') === '1') {
    $options[PDO::ATTR_PERSISTENT] = true;
}

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    // catat detail error ke log server (aman)
    error_log('[db_config] Database connection error: ' . $e->getMessage());

    // tampilkan pesan generik ke user — jangan tampilkan detail sensitif
    if (php_sapi_name() === 'cli') {
        // saat dijalankan di CLI (development), tampilkan detail agar lebih mudah debugging
        fwrite(STDERR, "Database connection failed: " . $e->getMessage() . PHP_EOL);
    }

    exit('Koneksi ke database gagal. Silakan hubungi administrator.');
}
