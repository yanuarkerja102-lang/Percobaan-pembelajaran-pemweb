<?php
session_start();
require_once "db_config.php";

// Jika form daftar dikirim, proses di sini
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['nama'])) {
    $nama = trim($_POST['nama']);
    $email = trim($_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $jenis_kelamin = $_POST['jenis_kelamin'];
    $no_hp = $_POST['no_hp'];

    // Cek apakah email sudah terdaftar
    $cek = $pdo->prepare("SELECT id FROM users WHERE email = :email");
    $cek->execute([':email' => $email]);

    if ($cek->rowCount() > 0) {
        echo "<script>alert('Email sudah terdaftar!');</script>";
    } else {
        $stmt = $pdo->prepare("INSERT INTO users (nama, email, password, jenis_kelamin, no_hp, role) VALUES (:nama, :email, :password, :jenis_kelamin, :no_hp, 'user')");
        $stmt->execute([
            ':nama' => $nama,
            ':email' => $email,
            ':password' => $password,
            ':jenis_kelamin' => $jenis_kelamin,
            ':no_hp' => $no_hp
        ]);

        // Setelah berhasil daftar, langsung redirect ke beranda
        $_SESSION['user_email'] = $email;
        $_SESSION['user_nama'] = $nama;
        $_SESSION['role'] = 'user';

        header("Location: beranda.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Volunteer - Masuk / Daftar</title>
  <link rel="stylesheet" href="volunteer.css">
  <style>
    body {
      background: linear-gradient(135deg, #00a86b, #9ef3c1);
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      color: #333;
    }

    .auth-container {
      display: flex;
      background: #fff;
      border-radius: 20px;
      overflow: hidden;
      box-shadow: 0 15px 40px rgba(0,0,0,0.1);
      width: 900px;
      max-width: 95%;
      animation: fadeIn 0.8s ease-in-out;
    }

    .auth-left {
      background: linear-gradient(180deg, #00a86b, #00945b);
      color: white;
      flex: 1;
      padding: 60px 30px;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      text-align: center;
    }

    .auth-left h1 {
      font-size: 2rem;
      margin-bottom: 15px;
    }

    .auth-left p {
      font-size: 1rem;
      opacity: 0.9;
    }

    .auth-right {
      flex: 1;
      padding: 40px 50px;
    }

    .tabs {
      display: flex;
      justify-content: center;
      margin-bottom: 25px;
    }

    .tab {
      flex: 1;
      text-align: center;
      padding: 10px 0;
      cursor: pointer;
      font-weight: 600;
      border-bottom: 3px solid transparent;
      transition: all 0.3s ease;
    }

    .tab.active {
      border-bottom: 3px solid #00a86b;
      color: #00a86b;
    }

    form {
      display: none;
      flex-direction: column;
      gap: 15px;
    }

    form.active {
      display: flex;
    }

    input, select {
      padding: 12px;
      border: 1px solid #ccc;
      border-radius: 8px;
      font-size: 0.95rem;
      transition: all 0.3s;
    }

    input:focus {
      border-color: #00a86b;
      box-shadow: 0 0 8px rgba(0, 168, 107, 0.3);
      outline: none;
    }

    button {
      background: linear-gradient(90deg, #00a86b, #00c47c);
      color: white;
      border: none;
      padding: 12px;
      border-radius: 30px;
      font-weight: 700;
      cursor: pointer;
      transition: all 0.3s ease;
    }

    button:hover {
      transform: scale(1.05);
      box-shadow: 0 6px 15px rgba(0, 168, 107, 0.3);
    }

    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(15px); }
      to { opacity: 1; transform: translateY(0); }
    }
  </style>
</head>
<body>

<div class="auth-container">
  <div class="auth-left">
    <h1>Volunteer Platform</h1>
    <p>Bergabung dan jadilah bagian dari perubahan. Daftar atau masuk untuk mulai berkontribusi!</p>
  </div>

  <div class="auth-right">
    <div class="tabs">
      <div class="tab active" onclick="showTab('login')">Masuk</div>
      <div class="tab" onclick="showTab('daftar')">Daftar</div>
    </div>

    <!-- Form Login -->
    <form id="login" class="active" method="POST" action="beranda.php">
      <input type="email" name="email" placeholder="Email" required>
      <input type="password" name="password" placeholder="Kata Sandi" required>
      <button type="submit">Masuk</button>
    </form>

    <!-- Form Daftar -->
    <form id="daftar" method="POST">
      <input type="text" name="nama" placeholder="Nama Lengkap" required>
      <input type="email" name="email" placeholder="Email" required>
      <input type="password" name="password" placeholder="Kata Sandi" required>
      <select name="jenis_kelamin" required>
        <option value="">Pilih Jenis Kelamin</option>
        <option value="Laki-laki">Laki-laki</option>
        <option value="Perempuan">Perempuan</option>
      </select>
      <input type="text" name="no_hp" placeholder="Nomor HP" required>
      <button type="submit">Daftar</button>
    </form>
  </div>
</div>

<script>
function showTab(tabName) {
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('form').forEach(f => f.classList.remove('active'));

  document.querySelector(`.tab[onclick="showTab('${tabName}')"]`).classList.add('active');
  document.getElementById(tabName).classList.add('active');
}
</script>

</body>
</html>
