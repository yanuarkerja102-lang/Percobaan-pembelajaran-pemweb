<?php
// admin_dashboard.php
session_start();
require_once __DIR__ . '/header.php';
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
    header('Location: admin_login.php');
    exit;
}
?>
<section>
  <h2>Dashboard Admin</h2>
  <p>Selamat datang, <?php echo htmlspecialchars($_SESSION['user_email']); ?>.</p>
  <p><a href="logout.php">Logout</a></p>
  <!-- tambahkan menu manajemen data di sini -->
</section>
<?php require_once __DIR__ . '/footer.php'; ?>
