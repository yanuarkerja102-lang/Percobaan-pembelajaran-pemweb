<?php
// daftar-relawan.php
require_once __DIR__ . '/header.php';
require_once __DIR__ . '/db_config.php';

$flash = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // ambil dan sanitize
    $nama     = trim($_POST['nama'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $hp       = trim($_POST['hp'] ?? '');
    $minat    = trim($_POST['minat'] ?? '');
    $keahlian = trim($_POST['keahlian'] ?? '');

    // validasi sederhana
    if ($nama === '' || $email === '') {
        $flash = 'Nama dan email wajib diisi.';
    } else {
        // INSERT ke tabel `relawan`
        $sql = "INSERT INTO relawan (nama, email, hp, minat, keahlian, created_at)
                VALUES (:nama, :email, :hp, :minat, :keahlian, NOW())";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':nama'     => $nama,
            ':email'    => $email,
            ':hp'       => $hp,
            ':minat'    => $minat,
            ':keahlian' => $keahlian,
        ]);
        $flash = 'Terima kasih — pendaftaran relawan Anda telah diterima.';
        // kosongkan nilai POST agar form menjadi bersih
        $_POST = [];
    }
}
?>
<section>
  <h2>Formulir Pendaftaran Relawan</h2>
  <?php if ($flash): ?>
    <p><strong><?php echo htmlspecialchars($flash); ?></strong></p>
  <?php endif; ?>
  <form method="post" action="">
    <label>Nama Lengkap:</label>
    <input type="text" name="nama" value="<?php echo htmlspecialchars($_POST['nama'] ?? ''); ?>">

    <label>Email:</label>
    <input type="email" name="email" value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>">

    <label>Nomor HP:</label>
    <input type="text" name="hp" value="<?php echo htmlspecialchars($_POST['hp'] ?? ''); ?>">

    <label>Minat Relawan:</label>
    <select name="minat">
      <option value="baksos" <?php if(($_POST['minat'] ?? '')==='baksos') echo 'selected'; ?>>Bakti Sosial</option>
      <option value="bencana" <?php if(($_POST['minat'] ?? '')==='bencana') echo 'selected'; ?>>Respon Bencana</option>
      <option value="pendidikan" <?php if(($_POST['minat'] ?? '')==='pendidikan') echo 'selected'; ?>>Pendidikan</option>
    </select>

    <label>Keahlian:</label>
    <textarea name="keahlian"><?php echo htmlspecialchars($_POST['keahlian'] ?? ''); ?></textarea>

    <button type="submit">Daftar</button>
  </form>
</section>
<?php require_once __DIR__ . '/footer.php'; ?>
