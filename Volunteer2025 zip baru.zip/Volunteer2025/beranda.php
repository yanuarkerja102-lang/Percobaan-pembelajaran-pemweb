<?php
// index.php
require_once __DIR__ . '/header.php';
?>
<section id="beranda">
  <h2>Selamat Datang di Portal Relawan</h2>
  <p>Bersama BAZNAS Jatim, mari bergabung menjadi relawan untuk membantu sesama.</p>
  <a href="pendaftaran-relawan.php">Daftar Jadi Relawan</a>
</section>

<section id="artikel">
  <h2>Artikel & Berita Terbaru</h2>

  <!-- Artikel 1 -->
  <article>
    <h3>BAZNAS Jatim Gali Potensi Zakat ASN di Wilayah Pendidikan Bojonegoro–Tuban</h3>
    <p><strong>📅 Tanggal:</strong> 24 Oktober 2025<br>
       <strong>📍 Lokasi:</strong> Bojonegoro–Tuban</p>
    <details>
      <summary style="cursor:pointer; color:#007bff;">📖 Baca Selengkapnya</summary>
      <p>
        BAZNAS Provinsi Jawa Timur melaksanakan kegiatan Sosialisasi Optimalisasi Pengumpulan Zakat, Infak, dan Sedekah (ZIS) di lingkungan pendidikan wilayah Bojonegoro–Tuban, bertempat di Kantor Cabang Dinas Pendidikan (Cabdindik) setempat. Kegiatan ini dihadiri oleh perwakilan kepala sekolah SMA/SMK/SLB negeri dan swasta, pejabat Cabdindik, serta pengurus Unit Pengumpul Zakat (UPZ) dari berbagai instansi pendidikan.
      </p>
      <p>
        Dalam kegiatan tersebut, Ketua BAZNAS Jatim menyampaikan bahwa potensi zakat profesi dari ASN di wilayah tersebut mencapai sekitar Rp 324 juta per bulan, namun realisasinya masih rendah, hanya sekitar Rp 16 juta per bulan.
      </p>
      <p>
        Beliau menegaskan bahwa ASN yang menerima penghasilan dari negara memiliki kewajiban untuk menunaikan zakat melalui BAZNAS sesuai amanat UU No. 23 Tahun 2011 dan Instruksi Presiden. Kegiatan ini diakhiri dengan komitmen bersama antara BAZNAS Jatim dan pihak Cabdindik untuk membentuk lebih banyak UPZ sekolah agar zakat profesi ASN tenaga pendidik dapat dilakukan secara rutin dan terstruktur.
      </p>
    </details>
    <a href="#"></a>
  </article>

  <!-- Artikel 2 -->
  <article>
    <h3>BAZNAS Jatim Gelar Bimtek RKAT 2026, Perkuat Program Tematik dan Sinergi</h3>
    <p><strong>📅 Tanggal:</strong> 29-31 Oktober 2025<br>
       <strong>📍 Lokasi:</strong> Sidoarjo</p>
    <details>
      <summary style="cursor:pointer; color:#007bff;">📖 Baca Selengkapnya</summary>
      <p>
        Dalam rangka mempersiapkan arah kebijakan dan program kerja tahun 2026, BAZNAS Provinsi Jawa Timur mengadakan Bimbingan Teknis (Bimtek) Penyusunan Rencana Kerja dan Anggaran Tahunan (RKAT) 2026 yang diikuti oleh seluruh BAZNAS kabupaten/kota se-Jawa Timur.
      </p>
      <p>
        Ketua BAZNAS Jatim menekankan bahwa penyusunan RKAT bukan sekadar rutinitas administratif, tetapi strategi memastikan setiap program memiliki dampak nyata bagi mustahik. Ia menekankan pentingnya penguatan program tematik yang terarah pada dua dimensi utama: pemberdayaan ekonomi (economy uplift) dan pencerahan spiritual (enlightenment).
      </p>
      <p>
        Plt. Asisten I Bidang Pemerintahan dan Kesejahteraan Rakyat Pemprov Jatim mengapresiasi kontribusi BAZNAS Jatim dalam mendukung program pengentasan kemiskinan, serta menekankan kerjasama sinergis antara BAZNAS dan pemerintah daerah. Selain itu, terdapat sesi narasumber dari BAZNAS RI, OJK, dan tim IT BAZNAS Jatim yang memaparkan digitalisasi sistem monitoring zakat berbasis web dan mobile.
      </p>
    </details>
    <a href="#"></a>
  </article>

  <!-- Artikel 3 -->
  <article>
    <h3>BAZNAS Jatim Tanggap Cepat Bencana Musala Runtuh di Ponpes Al-Khoziny Sidoarjo</h3>
    <p><strong>📅 Tanggal:</strong> 30 September 2025<br>
       <strong>📍 Lokasi:</strong> Sidoarjo</p>
    <details>
      <summary style="cursor:pointer; color:#007bff;">📖 Baca Selengkapnya</summary>
      <p>
        Tim Tanggap Bencana (BTB) BAZNAS Provinsi Jawa Timur menurunkan personel Search and Rescue untuk membantu evakuasi korban musala yang runtuh di Pondok Pesantren Al‑Khoziny, Kecamatan Buduran, Sidoarjo. Kegiatan ini melibatkan BTB kabupaten/kota se-Jawa Timur dan didukung oleh layanan dapur umum, air bersih, dan kesehatan melalui Rumah Sehat BAZNAS.
      </p>
      <p>
        Hingga Selasa (30/9) siang, tim BTB bersama Basarnas, BPBD, dan relawan lainnya masih terus memberikan bantuan. Posko koordinasi dan distribusi didirikan di lokasi, dan bantuan telah disalurkan ke beberapa titik distribusi di sekitar pesantren untuk memenuhi kebutuhan dasar korban dan relawan.
      </p>
    </details>
    <a href="#"></a>
  </article>

</section>