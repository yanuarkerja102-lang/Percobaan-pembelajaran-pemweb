<?php
// program.php
require_once __DIR__ . '/header.php';
?>
<section>
  <h2>Program Relawan</h2>
  <div class="program-item">
    <h3>Bakti Sosial</h3>
    <p>Kegiatan sosial membantu masyarakat yang membutuhkan.</p>
    <a href="#">Lihat Detail</a>
  </div>
  <div class="program-item">
    <h3>Respon Bencana</h3>
    <p>Bergabung dalam tim tanggap darurat bencana alam.</p>
    <a href="#">Lihat Detail</a>
  </div>
  <div class="program-item">
    <h3>Pendidikan</h3>
    <p>Relawan pengajar untuk anak-anak kurang mampu.</p>
    <a href="#">Lihat Detail</a>
  </div>
</section>
<?php require_once __DIR__ . '/footer.php'; ?>
