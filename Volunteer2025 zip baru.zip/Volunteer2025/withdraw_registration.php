<?php
// withdraw_registration.php
session_start();
require_once __DIR__ . '/db_config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: profile.php');
    exit;
}
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// CSRF check
if (!isset($_POST['csrf']) || !isset($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf'])) {
    $_SESSION['flash_error'] = 'Token keamanan tidak valid.';
    header('Location: profile.php');
    exit;
}

$uid = (int)$_SESSION['user_id'];
$reg_id = isset($_POST['registration_id']) ? (int)$_POST['registration_id'] : 0;
$reason = trim($_POST['reason'] ?? '');

if ($reg_id <= 0) {
    $_SESSION['flash_error'] = 'Permintaan tidak valid.';
    header('Location: profile.php');
    exit;
}

try {
    // fetch registration
    $stmt = $pdo->prepare("SELECT id, user_id, status FROM registrations WHERE id = :id LIMIT 1");
    $stmt->execute([':id' => $reg_id]);
    $reg = $stmt->fetch();

    if (!$reg) {
        $_SESSION['flash_error'] = 'Pendaftaran tidak ditemukan.';
        header('Location: profile.php');
        exit;
    }
    if ((int)$reg['user_id'] !== $uid) {
        $_SESSION['flash_error'] = 'Anda tidak berwenang membatalkan pendaftaran ini.';
        header('Location: profile.php');
        exit;
    }
    if ($reg['status'] !== 'pending') {
        $_SESSION['flash_error'] = 'Hanya pendaftaran dengan status pending yang bisa dibatalkan.';
        header('Location: profile.php');
        exit;
    }

    // Update jadi 'cancelled' dan simpan alasan; fallback ke 'rejected' jika enum tidak support
    try {
        $upd = $pdo->prepare("UPDATE registrations SET status = 'cancelled', withdrawn_at = NOW(), withdraw_reason = :reason, withdrawn_by = :by WHERE id = :id");
        $upd->execute([':reason' => $reason ?: null, ':by' => $uid, ':id' => $reg_id]);
        $ok = $upd->rowCount() > 0;
    } catch (PDOException $e) {
        // fallback
        $upd2 = $pdo->prepare("UPDATE registrations SET status = 'rejected' WHERE id = :id");
        $upd2->execute([':id' => $reg_id]);
        $ok = $upd2->rowCount() > 0;
    }

    if ($ok) {
        $_SESSION['flash_success'] = 'Pendaftaran berhasil dibatalkan.';
    } else {
        $_SESSION['flash_error'] = 'Gagal membatalkan pendaftaran.';
    }

    header('Location: profile.php');
    exit;

} catch (Exception $e) {
    error_log('[withdraw_registration] ' . $e->getMessage());
    $_SESSION['flash_error'] = 'Terjadi kesalahan sistem.';
    header('Location: profile.php');
    exit;
}
