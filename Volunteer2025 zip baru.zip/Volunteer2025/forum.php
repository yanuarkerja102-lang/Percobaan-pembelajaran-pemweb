<?php
// forum.php (Reddit-style tanpa vote, versi bebas error)
session_start();
require_once __DIR__ . '/header.php';
require_once __DIR__ . '/db_config.php';

$flash = '';
$reply_to = isset($_GET['reply_to']) ? (int)$_GET['reply_to'] : null;

// === Simpan Post / Balasan ===
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $diskusi = trim($_POST['diskusi'] ?? '');
    $parent_id = isset($_POST['parent_id']) && $_POST['parent_id'] !== '' ? (int)$_POST['parent_id'] : null;

    $author = 'Anon';
    $user_id = null;
    if (isset($_SESSION['user_id'])) {
        $user_id = $_SESSION['user_id'];
        $author  = $_SESSION['user_email'] ?? 'User';
    }

    if ($diskusi === '') {
        $flash = '❗ Isi diskusi tidak boleh kosong.';
    } else {
        try {
            $stmt = $pdo->prepare("
                INSERT INTO forum_posts (parent_id, user_id, author_name, content, created_at)
                VALUES (:parent_id, :user_id, :author_name, :content, NOW())
            ");
            // Gunakan null jika parent_id kosong
            $stmt->bindValue(':parent_id', $parent_id, $parent_id === null ? PDO::PARAM_NULL : PDO::PARAM_INT);
            $stmt->bindValue(':user_id', $user_id, $user_id === null ? PDO::PARAM_NULL : PDO::PARAM_INT);
            $stmt->bindValue(':author_name', $author, PDO::PARAM_STR);
            $stmt->bindValue(':content', $diskusi, PDO::PARAM_STR);
            $stmt->execute();

            $flash = '💬 Diskusi berhasil ditambahkan.';
            header("Location: forum.php");
            exit;
        } catch (PDOException $e) {
            $flash = '⚠️ Gagal menyimpan ke database: ' . $e->getMessage();
        }
    }
}

// === Ambil data semua post ===
$stmt = $pdo->query("
    SELECT id, parent_id, author_name, content, created_at
    FROM forum_posts
    ORDER BY created_at ASC
");
$rows = $stmt->fetchAll();

// === Susun jadi tree (thread) ===
function buildTree(array $rows, $parentId = null): array {
    $branch = [];
    foreach ($rows as $row) {
        if ($row['parent_id'] == $parentId) {
            $children = buildTree($rows, $row['id']);
            if ($children) {
                $row['replies'] = $children;
            }
            $branch[] = $row;
        }
    }
    return $branch;
}
$threads = buildTree($rows);

// === Render Thread ===
function renderPost($post, $level = 0) {
    $margin = $level * 24;
    echo '<div class="post" style="margin-left:' . $margin . 'px;">';
    echo '<div class="post-body">';
    echo '<div class="post-content">';
    echo '<p>' . nl2br(htmlspecialchars($post['content'])) . '</p>';
    echo '<div class="meta">';
    echo '<small>👤 ' . htmlspecialchars($post['author_name']) . ' • ' . htmlspecialchars(date('d M Y H:i', strtotime($post['created_at']))) . '</small>';
    echo '</div>';
    echo '<div class="buttons">';
    echo '<a class="btn-reply" href="?reply_to=' . $post['id'] . '">💬 Balas</a>';
    echo '</div>';
    echo '</div></div>';

    if (!empty($post['replies'])) {
        foreach ($post['replies'] as $child) {
            renderPost($child, $level + 1);
        }
    }
    echo '</div>';
}
?>

<section class="forum-container">
  <h2>Forum Diskusi Relawan</h2>

  <?php if ($flash): ?>
    <div class="alert"><?php echo htmlspecialchars($flash); ?></div>
  <?php endif; ?>

  <form method="post" action="" class="new-post-form">
    <h3><?php echo $reply_to ? 'Balas Diskusi #' . htmlspecialchars($reply_to) : 'Tulis Diskusi Baru'; ?></h3>
    <?php if ($reply_to): ?>
      <input type="hidden" name="parent_id" value="<?php echo (int)$reply_to; ?>">
      <a href="forum.php" class="btn-secondary">⬅️ Kembali ke Forum</a>
    <?php else: ?>
      <input type="hidden" name="parent_id" value="">
    <?php endif; ?>

    <textarea name="diskusi" rows="4" placeholder="Tulis pendapatmu..." required></textarea>
    <button type="submit" class="btn-primary">🚀 Kirim</button>
  </form>

  <hr>

  <h3>🗨️ Diskusi Terbaru</h3>
  <?php if (empty($threads)): ?>
    <p>Belum ada diskusi. Jadilah yang pertama!</p>
  <?php else: ?>
    <div class="thread-list">
      <?php foreach ($threads as $thread): ?>
        <?php renderPost($thread); ?>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</section>

<style>
.forum-container { max-width: 800px; margin: auto; padding: 20px; }
.alert { background: #e6ffe6; padding: 10px; border-radius: 8px; border-left: 4px solid #2ecc71; }
.new-post-form textarea {
  width: 100%; padding: 8px; border-radius: 6px; border: 1px solid #ccc; resize: vertical;
}
.btn-primary {
  display: inline-block; background: #02bd40ff; color: #fff;
  border: none; padding: 8px 14px; border-radius: 6px;
  cursor: pointer; font-weight: 600; margin-top: 8px;
}
.btn-primary:hover { background: #078136ff; }

.btn-secondary {
  display: inline-block; background: #f0f0f0; color: #333;
  padding: 6px 12px; border-radius: 6px; text-decoration: none;
  border: 1px solid #ccc; margin-bottom: 10px;
}
.btn-secondary:hover { background: #e0e0e0; }

.post {
  margin-top: 16px; border-left: 2px solid #ccc; padding-left: 12px;
}
.post-body { display: flex; gap: 8px; align-items: flex-start; }
.post-content {
  flex: 1; background: #fafafa; border-radius: 8px; padding: 10px;
}
.post-content p { margin: 0 0 8px 0; }
.meta small { color: #555; font-size: 0.85em; }
.buttons { margin-top: 6px; }
.btn-reply {
  display: inline-block; background: #f8f9fa; color: #006d3c;
  border: 1px solid #14a740ff; border-radius: 4px;
  padding: 4px 8px; font-size: 0.85em; text-decoration: none;
}
.btn-reply:hover { background: #00ff4cff; color: white; }
</style>

<?php require_once __DIR__ . '/footer.php'; ?>
